#!/bin/bash
nohup python3 01_crea_msg_anual.py "2010" > crea_msg_2010.log 2>&1 &
nohup python3 01_crea_msg_anual.py "2011" > crea_msg_2011.log 2>&1 &
nohup python3 01_crea_msg_anual.py "2012" > crea_msg_2012.log 2>&1 &
nohup python3 01_crea_msg_anual.py "2013" > crea_msg_2013.log 2>&1 &
nohup python3 01_crea_msg_anual.py "2014" > crea_msg_2014.log 2>&1 &
nohup python3 01_crea_msg_anual.py "2015" > crea_msg_2015.log 2>&1 &
nohup python3 01_crea_msg_anual.py "2016" > crea_msg_2016.log 2>&1 &
nohup python3 01_crea_msg_anual.py "2017" > crea_msg_2017.log 2>&1 &
nohup python3 01_crea_msg_anual.py "2018" > crea_msg_2018.log 2>&1 &
nohup python3 01_crea_msg_anual.py "2019" > crea_msg_2019.log 2>&1 &
nohup python3 01_crea_msg_anual.py "2020" > crea_msg_2020.log 2>&1 &
nohup python3 01_crea_msg_anual.py "2021" > crea_msg_2021.log 2>&1 &
nohup python3 01_crea_msg_anual.py "2022" > crea_msg_2022.log 2>&1 &
#"python3 actualiza_msg.p_anualy "$parametro"
 