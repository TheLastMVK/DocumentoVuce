#!/bin/bash
nohup python3 01_crea_cab.py "2010" > crea_cab_2010.log 2>&1 &
nohup python3 01_crea_cab.py "2011" > crea_cab_2011.log 2>&1 &
nohup python3 01_crea_cab.py "2012" > crea_cab_2012.log 2>&1 &
nohup python3 01_crea_cab.py "2013" > crea_cab_2013.log 2>&1 &
nohup python3 01_crea_cab.py "2014" > crea_cab_2014.log 2>&1 &
nohup python3 01_crea_cab.py "2015" > crea_cab_2015.log 2>&1 &
nohup python3 01_crea_cab.py "2016" > crea_cab_2016.log 2>&1 &
nohup python3 01_crea_cab.py "2017" > crea_cab_2017.log 2>&1 &

nohup python3 01_crea_cab.py "2018" > crea_cab_2018.log 2>&1 &
nohup python3 01_crea_cab.py "2019" > crea_cab_2019.log 2>&1 &
nohup python3 01_crea_cab.py "2020" > crea_cab_2020.log 2>&1 &
nohup python3 01_crea_cab.py "2021" > crea_cab_2021.log 2>&1 &
nohup python3 01_crea_cab.py "2022" > crea_cab_2022.log 2>&1 &

#"python3 actualiza_msg.py "$parametro"
