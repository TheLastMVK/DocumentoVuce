#!/bin/bash
# Mostrar fecha y hora de ejecución
echo "Fecha y hora de ejecución: $(date)"
echo
# Ejecutar el comando telnet
echo "Ejecutando comando Telnet..."
telnet 192.168.90.18 9080
