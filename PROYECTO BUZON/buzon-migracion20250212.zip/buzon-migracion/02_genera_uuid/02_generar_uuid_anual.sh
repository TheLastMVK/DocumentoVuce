# Obtener el parámetro pasado al script
#parametro="$1"
nohup java -jar filenetadj.jar 2013 >> 02_genera_uuid_anual_2013.log 2>&1 &
nohup java -jar filenetadj.jar 2014 >> 02_genera_uuid_anual_2014.log 2>&1 &
nohup java -jar filenetadj.jar 2015 >> 02_genera_uuid_anual_2015.log 2>&1 &
nohup java -jar filenetadj.jar 2016 >> 02_genera_uuid_anual_2016.log 2>&1 &
nohup java -jar filenetadj.jar 2017 >> 02_genera_uuid_anual_2017.log 2>&1 &
nohup java -jar filenetadj.jar 2018 >> 02_genera_uuid_anual_2018.log 2>&1 &
nohup java -jar filenetadj.jar 2019 >> 02_genera_uuid_anual_2019.log 2>&1 &
nohup java -jar filenetadj.jar 2020 >> 02_genera_uuid_anual_2020.log 2>&1 &
nohup java -jar filenetadj.jar 2021 >> 02_genera_uuid_anual_2021.log 2>&1 &
nohup java -jar filenetadj.jar 2022 >> 02_genera_uuid_anual_2022.log 2>&1 &


nohup python3 02_generar_uuid_anual.py "2010" >> 02_genera_uuid_anual_2010.log 2>&1 &
nohup python3 02_generar_uuid_anual.py "2011" >> 02_genera_uuid_anual_2011.log 2>&1 &
nohup python3 02_generar_uuid_anual.py "2012" >> 02_genera_uuid_anual_2012.log 2>&1 &
nohup python3 02_generar_uuid_anual.py "2013" >> 02_genera_uuid_anual_2013.log 2>&1 &
nohup python3 02_generar_uuid_anual.py "2014" >> 02_genera_uuid_anual_2014.log 2>&1 &
nohup python3 02_generar_uuid_anual.py "2015" >> 02_genera_uuid_anual_2015.log 2>&1 &
nohup python3 02_generar_uuid_anual.py "2016" >> 02_genera_uuid_anual_2016.log 2>&1 &
nohup python3 02_generar_uuid_anual.py "2017" >> 02_genera_uuid_anual_2017.log 2>&1 &
nohup python3 02_generar_uuid_anual.py "2018" >> 02_genera_uuid_anual_2018.log 2>&1 &
nohup python3 02_generar_uuid_anual.py "2019" >> 02_genera_uuid_anual_2019.log 2>&1 &
nohup python3 02_generar_uuid_anual.py "2020" >> 02_genera_uuid_anual_2020.log 2>&1 &
nohup python3 02_generar_uuid_anual.py "2021" >> 02_genera_uuid_anual_2021.log 2>&1 &
nohup python3 02_generar_uuid_anual.py "2022" >> 02_genera_uuid_anual_2022.log 2>&1 &

anno="2012"

nohup java -jar filenetmes.jar 201801 >> 02_genera_uuid_mensual_201801.log 2>&1 &
nohup java -jar filenetmes.jar 201802 >> 02_genera_uuid_mensual_201802.log 2>&1 &
nohup java -jar filenetmes.jar 201803 >> 02_genera_uuid_mensual_201803.log 2>&1 &
nohup java -jar filenetmes.jar 201804 >> 02_genera_uuid_mensual_201804.log 2>&1 &
nohup java -jar filenetmes.jar 201805 >> 02_genera_uuid_mensual_201805.log 2>&1 &
nohup java -jar filenetmes.jar 201806 >> 02_genera_uuid_mensual_201806.log 2>&1 &
nohup java -jar filenetmes.jar 201807 >> 02_genera_uuid_mensual_201807.log 2>&1 &
nohup java -jar filenetmes.jar 201808 >> 02_genera_uuid_mensual_201808.log 2>&1 &
nohup java -jar filenetmes.jar 201809 >> 02_genera_uuid_mensual_201809.log 2>&1 &
nohup java -jar filenetmes.jar 201810 >> 02_genera_uuid_mensual_201810.log 2>&1 &
nohup java -jar filenetmes.jar 201811 >> 02_genera_uuid_mensual_201811.log 2>&1 &
nohup java -jar filenetmes.jar 201812 >> 02_genera_uuid_mensual_201812.log 2>&1 &

