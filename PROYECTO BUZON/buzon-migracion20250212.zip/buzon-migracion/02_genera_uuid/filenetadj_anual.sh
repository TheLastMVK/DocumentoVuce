# Obtener el parámetro pasado al script
#parametro="$1"
nohup java -jar filenetadj.jar 2013 >> 02_genera_uuid_anual_2013.log 2>&1 &
nohup java -jar filenetadj.jar 2014 >> 02_genera_uuid_anual_2014.log 2>&1 &
nohup java -jar filenetadj.jar 2015 >> 02_genera_uuid_anual_2015.log 2>&1 &
nohup java -jar filenetadj.jar 2016 >> 02_genera_uuid_anual_2016.log 2>&1 &
nohup java -jar filenetadj.jar 2017 >> 02_genera_uuid_anual_2017.log 2>&1 &
nohup java -jar filenetadj.jar 2018 >> 02_genera_uuid_anual_2018.log 2>&1 &


nohup java -jar filenetadj.jar 2019 >> 02_genera_uuid_anual_2019.log 2>&1 &
nohup java -jar filenetadj.jar 2020 >> 02_genera_uuid_anual_2020.log 2>&1 &
nohup java -jar filenetadj.jar 2021 >> 02_genera_uuid_anual_2021.log 2>&1 &
nohup java -jar filenetadj.jar 2022 >> 02_genera_uuid_anual_2022.log 2>&1 &


"4882639","12967230"
"12967230","25934460"
"25934460","38901691"
"38901691","51868921"
"51868921","64836151"
