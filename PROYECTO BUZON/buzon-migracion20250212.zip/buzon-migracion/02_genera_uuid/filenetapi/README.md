# filenetapi

API REST con las funciones CRUD para el manejo de archivos en el FileNet