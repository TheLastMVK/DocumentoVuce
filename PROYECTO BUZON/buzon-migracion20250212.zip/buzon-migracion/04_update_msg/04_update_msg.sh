anno="2012"
nohup python3 04_update_msg.py "${anno}01" > update_msg_${anno}01.log 2>&1 &
nohup python3 04_update_msg.py "${anno}02" > update_msg_${anno}02.log 2>&1 &
nohup python3 04_update_msg.py "${anno}03" > update_msg_${anno}03.log 2>&1 &
nohup python3 04_update_msg.py "${anno}04" > update_msg_${anno}04.log 2>&1 &
nohup python3 04_update_msg.py "${anno}05" > update_msg_${anno}05.log 2>&1 &
nohup python3 04_update_msg.py "${anno}06" > update_msg_${anno}06.log 2>&1 &
nohup python3 04_update_msg.py "${anno}07" > update_msg_${anno}07.log 2>&1 &
nohup python3 04_update_msg.py "${anno}08" > update_msg_${anno}08.log 2>&1 &
nohup python3 04_update_msg.py "${anno}09" > update_msg_${anno}09.log 2>&1 &
nohup python3 04_update_msg.py "${anno}10" > update_msg_${anno}10.log 2>&1 &
nohup python3 04_update_msg.py "${anno}11" > update_msg_${anno}11.log 2>&1 &
nohup python3 04_update_msg.py "${anno}12" > update_msg_${anno}12.log 2>&1 &