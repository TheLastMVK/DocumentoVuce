
nohup python3 05_union_msg_anual.py "2010" >> union_msg_2010.log 2>&1 &
nohup python3 05_union_msg_anual.py "2011" >> union_msg_2011.log 2>&1 &
nohup python3 05_union_msg_anual.py "2012" >> union_msg_2012.log 2>&1 &
nohup python3 05_union_msg_anual.py "2013" >> union_msg_2013.log 2>&1 &
nohup python3 05_union_msg_anual.py "2014" >> union_msg_2014.log 2>&1 &
nohup python3 05_union_msg_anual.py "2015" >> union_msg_2015.log 2>&1 &
nohup python3 05_union_msg_anual.py "2016" >> union_msg_2016.log 2>&1 &
nohup python3 05_union_msg_anual.py "2017" >> union_msg_2017.log 2>&1 &
nohup python3 05_union_msg_anual.py "2018" >> union_msg_2018.log 2>&1 &

nohup python3 05_union_msg_anual.py "2019" >> union_msg_2019.log 2>&1 &
nohup python3 05_union_msg_anual.py "2020" >> union_msg_2020.log 2>&1 &
nohup python3 05_union_msg_anual.py "2021" >> union_msg_2021.log 2>&1 &

nohup python3 05_union_msg_anual.py "2022" >> union_msg_2022.log 2>&1 &
nohup python3 05_union_msg_anual.py "2023" >> union_msg_2023.log 2>&1 &
nohup python3 05_union_msg_anual.py "2024" >> union_msg_2024.log 2>&1 &